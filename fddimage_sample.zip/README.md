# fddimage_sample.zip

PC-98ブラウザエミュレータページ (index.html) の動作確認用サンプルです。
「fddimage.zipを読み込む」からこのzipを指定すると、実機ROMなしで
起動デモディスクを試せます（エミュレータ内蔵の互換BIOSで起動します）。

## このサンプルの構造

```
fddimage_sample.zip
├── index.json    ... タイトル一覧
├── sample.d88    ... 起動デモディスク D88形式（自作・MITライセンス）
├── sample.tfd    ... 起動デモディスク TFD形式（同上）
├── font.bmp      ... フォント（Neko Project II 付属・BSD-3-Clause）
└── README.md     ... このファイル
```

## 完全版 fddimage.zip の構造

実機ROMとディスクイメージを揃えた場合の構成です。ROMもディスクも
すべて同じzipの中に入れます:

```
fddimage.zip
├── index.json      ... タイトル一覧
├── bios.rom        ... 実機から吸い出したBIOS ROM
├── font.rom        ... 実機から吸い出したフォントROM
├── itf.rom         ... 実機から吸い出したITF ROM（任意）
├── msdos.fdi       ┐
├── wordproc.d88    │
├── hyokeisan.d88   │ ディスクイメージは何枚でも入れられます。
├── kaihatsu.d88    │ 形式は混在可です
├── basic_apps.tfd  │ (d88/88d/d98/98d/fdi/tfd/xdf/hdm)。
├── tsushin.tfd     │
├── freesoft01.tfd  │
└── ...             ┘
```

zip直下でなくフォルダにまとめてからzip化しても認識されます
（パスではなくファイル名で判別します）。
bios.rom が無い場合は内蔵互換BIOSで起動しますが、N88-BASIC で
書かれたソフトは動きません。font.rom が無い場合は font.bmp で代用できます。

## index.json のフォーマット

zipに入れたディスクの分だけエントリを並べます。内容はPC-98用の
ソフトウェアなら何でも構いません:

```json
[
 {"filename": "msdos.fdi",      "category": "システム",         "title": "MS-DOS"},
 {"filename": "wordproc.d88",   "category": "アプリケーション", "title": "ワープロ"},
 {"filename": "hyokeisan.d88",  "category": "アプリケーション", "title": "表計算"},
 {"filename": "kaihatsu.d88",   "category": "開発",             "title": "アセンブラ・開発ツール"},
 {"filename": "basic_apps.tfd", "category": "自作",             "title": "N88-BASICの自作プログラム集"},
 {"filename": "tsushin.tfd",    "category": "通信",             "title": "通信ソフト"},
 {"filename": "freesoft01.tfd", "category": "フリーソフト",     "title": "フリーソフト集 1"}
]
```

category ごとにグループ化されて選択リストに表示されます。
ディスク以外のファイル（ROM等）は書いてもリストには並びません。

## 注意

ROMや市販ソフトのディスクイメージは著作物です。自分が所有する実機・
メディアからの私的複製の範囲で使用し、zipを再配布しないでください。
